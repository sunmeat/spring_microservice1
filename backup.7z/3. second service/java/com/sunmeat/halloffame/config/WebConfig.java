package com.sunmeat.halloffame.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // cервіруємо файли з папки 'uploads' за URL /uploads/**
        // './uploads' — відносний шлях від кореня проекту, там де build.gradle
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:./uploads/");
    }
}